/**
 * Módulo de API
 * Gerencia todas as requisições HTTP para o backend
 */

class CloudAPI {
    constructor() {
        this.baseURL = 'http://localhost:8000';
        this.token = localStorage.getItem('auth_token');
    }

    /**
     * Faz login
     */
    async login(password) {
        const response = await fetch(`${this.baseURL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ password }),
        });

        if (!response.ok) {
            const error = await response.json();
            throw error;
        }

        return await response.json();
    }

    /**
     * Lista arquivos
     */
    async listFiles(path = '') {
        const response = await fetch(`${this.baseURL}/files?path=${encodeURIComponent(path)}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${this.token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Erro ao listar arquivos');
        }

        return await response.json();
    }

    /**
     * Faz upload de arquivo
     */
    async uploadFile(file, path = '', onProgress = null) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('path', path);

        const xhr = new XMLHttpRequest();

        return new Promise((resolve, reject) => {
            if (onProgress) {
                xhr.upload.addEventListener('progress', onProgress);
            }

            xhr.addEventListener('load', () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(JSON.parse(xhr.responseText));
                } else {
                    reject(new Error('Erro ao fazer upload'));
                }
            });

            xhr.addEventListener('error', () => {
                reject(new Error('Erro de conexão'));
            });

            xhr.open('POST', `${this.baseURL}/files/upload`);
            xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
            xhr.send(formData);
        });
    }

    /**
     * Faz download de arquivo
     */
    async downloadFile(path) {
        const response = await fetch(`${this.baseURL}/files/download/${encodeURIComponent(path)}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${this.token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Erro ao fazer download');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = path.split('/').pop();
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    /**
     * Deleta arquivo
     */
    async deleteFile(path) {
        const response = await fetch(`${this.baseURL}/files/${encodeURIComponent(path)}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${this.token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Erro ao deletar arquivo');
        }

        return await response.json();
    }

    /**
     * Cria pasta
     */
    async createFolder(folderName, parentPath = '') {
        const response = await fetch(`${this.baseURL}/folders`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                folder_name: folderName,
                parent_path: parentPath,
            }),
        });

        if (!response.ok) {
            throw new Error('Erro ao criar pasta');
        }

        return await response.json();
    }

    /**
     * Cria link de compartilhamento
     */
    async createShareLink(filePath, expirationHours, password = null, viewLimit = null) {
        // Hash da senha se fornecida
        let passwordHash = null;
        if (password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            passwordHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        }

        const response = await fetch(`${this.baseURL}/share`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                file_path: filePath,
                expiration_hours: expirationHours,
                password: passwordHash,
                view_limit: viewLimit,
            }),
        });

        if (!response.ok) {
            const error = await response.json();
            throw error;
        }

        return await response.json();
    }

    /**
     * Obtém URL de download direto
     */
    async getDownloadUrl(path) {
        const response = await fetch(`${this.baseURL}/files/${encodeURIComponent(path)}/download-url`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${this.token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Erro ao obter URL de download');
        }

        return await response.json();
    }

    /**
     * Obtém logs de atividade
     */
    async getActivityLogs() {
        const response = await fetch(`${this.baseURL}/activity-logs`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${this.token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Erro ao obter logs');
        }

        return await response.json();
    }
}

// Instância global da API
const api = new CloudAPI();
