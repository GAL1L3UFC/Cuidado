/**
 * Módulo de UI
 * Gerencia elementos da interface e notificações
 */

class CloudUI {
    constructor() {
        this.isDarkMode = localStorage.getItem('theme') === 'light' ? false : true;
        this.initTheme();
    }

    /**
     * Inicializa tema
     */
    initTheme() {
        if (!this.isDarkMode) {
            document.body.classList.add('light-mode');
        }
    }

    /**
     * Alterna tema
     */
    toggleTheme() {
        this.isDarkMode = !this.isDarkMode;
        
        if (this.isDarkMode) {
            document.body.classList.remove('light-mode');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.add('light-mode');
            localStorage.setItem('theme', 'light');
        }
    }

    /**
     * Alterna sidebar
     */
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.toggle('open');
        }
    }

    /**
     * Abre modal
     */
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            // Fechar ao clicar no overlay
            const overlay = modal.querySelector('.modal-overlay');
            if (overlay) {
                overlay.addEventListener('click', () => {
                    this.closeModal(modalId);
                });
            }
        }
    }

    /**
     * Fecha modal
     */
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    /**
     * Mostra notificação
     */
    showNotification(message, type = 'info', duration = 4000) {
        const container = document.getElementById('notifications-container') || this.createNotificationsContainer();
        
        const notification = document.createElement('div');
        notification.className = 'notification ' + type;
        notification.textContent = message;
        
        container.appendChild(notification);
        
        // Auto-remover após duração
        setTimeout(() => {
            notification.style.animation = 'slideInRight 0.3s ease reverse';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, duration);
    }

    /**
     * Cria container de notificações
     */
    createNotificationsContainer() {
        const container = document.createElement('div');
        container.id = 'notifications-container';
        container.className = 'notifications-container';
        document.body.appendChild(container);
        return container;
    }

    /**
     * Atualiza progresso de upload
     */
    updateUploadProgress(percent, speed, time) {
        const fill = document.getElementById('progress-fill');
        if (fill) {
            fill.style.width = percent + '%';
        }

        const percentEl = document.getElementById('progress-percent');
        if (percentEl) {
            percentEl.textContent = percent + '%';
        }

        const speedEl = document.getElementById('progress-speed');
        if (speedEl) {
            speedEl.textContent = speed;
        }

        const timeEl = document.getElementById('progress-time');
        if (timeEl) {
            timeEl.textContent = time;
        }
    }

    /**
     * Mostra/esconde progresso de upload
     */
    setUploadProgressVisible(visible) {
        const container = document.getElementById('upload-progress-container');
        if (container) {
            container.style.display = visible ? 'block' : 'none';
        }
    }

    /**
     * Atualiza informações da sidebar
     */
    updateSidebarInfo(totalSize, fileCount) {
        const totalSizeEl = document.getElementById('total-size');
        if (totalSizeEl) {
            totalSizeEl.textContent = totalSize;
        }

        const fileCountEl = document.getElementById('file-count');
        if (fileCountEl) {
            fileCountEl.textContent = fileCount;
        }
    }

    /**
     * Atualiza logs de atividade
     */
    updateActivityLogs(logs) {
        const logContainer = document.getElementById('activity-log');
        if (!logContainer) return;

        logContainer.innerHTML = logs.slice(0, 10).map(log => {
            return '<div class="activity-item">' + log.action + ' - ' + new Date(log.timestamp).toLocaleString() + '</div>';
        }).join('');

        if (logs.length === 0) {
            logContainer.innerHTML = '<div class="empty-state">Nenhuma atividade</div>';
        }
    }

    /**
     * Habilita/desabilita botão
     */
    setButtonDisabled(buttonId, disabled) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = disabled;
            button.style.opacity = disabled ? '0.5' : '1';
        }
    }

    /**
     * Mostra/esconde elemento
     */
    setElementVisible(elementId, visible) {
        const element = document.getElementById(elementId);
        if (element) {
            element.style.display = visible ? '' : 'none';
        }
    }

    /**
     * Limpa formulário
     */
    clearForm(formId) {
        const form = document.getElementById(formId);
        if (form) {
            form.reset();
        }
    }

    /**
     * Define valor de input
     */
    setInputValue(inputId, value) {
        const input = document.getElementById(inputId);
        if (input) {
            input.value = value;
        }
    }

    /**
     * Obtém valor de input
     */
    getInputValue(inputId) {
        const input = document.getElementById(inputId);
        return input ? input.value : '';
    }

    /**
     * Mostra erro em formulário
     */
    showFormError(formId, message) {
        const form = document.getElementById(formId);
        if (!form) return;

        // Remove erro anterior se existir
        const existingError = form.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        // Adiciona novo erro
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        form.appendChild(errorDiv);
    }

    /**
     * Limpa erros do formulário
     */
    clearFormErrors(formId) {
        const form = document.getElementById(formId);
        if (!form) return;

        const errors = form.querySelectorAll('.error-message');
        errors.forEach(error => error.remove());
    }
}

// Instância global da UI
const ui = new CloudUI();
