package nemosofts.online.live.utils.purchases.enums;

public enum SkuProductType {
    CONSUMABLE,
    NON_CONSUMABLE,
    SUBSCRIPTION
}
