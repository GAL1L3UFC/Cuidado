package nemosofts.online.live.utils.purchases.enums;

public enum SupportState {
    SUPPORTED,
    NOT_SUPPORTED,
    DISCONNECTED
}
