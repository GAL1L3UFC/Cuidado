package nemosofts.online.live.utils.purchases.enums;

public enum ProductType {
    INAPP,
    SUBS,
    COMBINED
}
