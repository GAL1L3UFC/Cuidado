/**
 * Módulo principal da aplicação
 * Gerencia a lógica de negócio e coordena a interação entre API e UI
 */

class CloudApp {
    constructor() {
        this.currentPath = '';
        this.files = [];
        this.isLoading = false;
        this.uploadStartTime = null;
        this.init();
    }

    /**
     * Inicializa a aplicação
     */
    init() {
        this.setupEventListeners();
        this.checkAuthentication();
    }

    /**
     * Configura listeners de eventos
     */
    setupEventListeners() {
        // Login
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Tema
        document.getElementById('toggle-theme').addEventListener('click', () => {
            ui.toggleTheme();
        });

        // Sidebar
        document.getElementById('toggle-sidebar').addEventListener('click', () => {
            ui.toggleSidebar();
        });

        // Upload
        document.getElementById('upload-btn').addEventListener('click', () => {
            document.getElementById('file-input').click();
        });

        document.getElementById('file-input').addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files);
            e.target.value = ''; // Reset input
        });

        // Criar pasta
        document.getElementById('create-folder-btn').addEventListener('click', () => {
            ui.openModal('folder-modal');
        });

        document.getElementById('folder-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleCreateFolder();
        });

        // Compartilhar
        document.getElementById('share-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleCreateShareLink();
        });

        document.getElementById('copy-share-link').addEventListener('click', () => {
            const input = document.getElementById('share-link-input');
            input.select();
            document.execCommand('copy');
            ui.showNotification('Link copiado para a área de transferência!', 'success');
        });

        // Atualizar
        document.getElementById('refresh-btn').addEventListener('click', () => {
            this.loadFiles();
        });

        // Busca
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.handleSearch(e.target.value);
        });

        // Breadcrumb
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('breadcrumb-item')) {
                e.preventDefault();
                const path = e.target.getAttribute('data-path') || '';
                this.currentPath = path;
                this.loadFiles();
            }
        });

        // Drop zone
        const dropZone = document.getElementById('drop-zone');
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            this.handleFileSelect(e.dataTransfer.files);
        });

        dropZone.addEventListener('click', () => {
            document.getElementById('file-input').click();
        });

        // Fechar modais
        document.querySelectorAll('.modal-close-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const modal = e.target.closest('.modal');
                if (modal) {
                    ui.closeModal(modal.id);
                }
            });
        });

        // Fechar upload progress
        document.querySelector('.upload-progress-container .btn-close')?.addEventListener('click', () => {
            document.getElementById('upload-progress-container').style.display = 'none';
        });
    }

    /**
     * Verifica autenticação
     */
    async checkAuthentication() {
        const token = localStorage.getItem('auth_token');
        if (token) {
            this.showDashboard();
            this.loadFiles();
        } else {
            this.showLoginScreen();
        }
    }

    /**
     * Mostra tela de login
     */
    showLoginScreen() {
        document.getElementById('login-screen').classList.add('active');
        document.getElementById('dashboard-screen').classList.remove('active');
    }

    /**
     * Mostra dashboard
     */
    showDashboard() {
        document.getElementById('login-screen').classList.remove('active');
        document.getElementById('dashboard-screen').classList.add('active');
    }

    /**
     * Trata login
     */
    async handleLogin() {
        const password = document.getElementById('password').value;

        if (!password) {
            ui.showNotification('Digite sua senha', 'error');
            return;
        }

        try {
            const response = await api.login(password);
            localStorage.setItem('auth_token', response.token);
            document.getElementById('password').value = '';
            this.showDashboard();
            this.loadFiles();
            ui.showNotification('Login realizado com sucesso!', 'success');
        } catch (error) {
            const errorMsg = error.response?.data?.detail || 'Erro ao fazer login';
            document.getElementById('login-error').textContent = errorMsg;
            document.getElementById('login-error').style.display = 'block';
            ui.showNotification(errorMsg, 'error');
        }
    }

    /**
     * Trata logout
     */
    handleLogout() {
        if (confirm('Tem certeza que deseja sair?')) {
            localStorage.removeItem('auth_token');
            this.showLoginScreen();
            ui.showNotification('Você foi desconectado', 'info');
        }
    }

    /**
     * Carrega lista de arquivos
     */
    async loadFiles() {
        if (this.isLoading) return;

        this.isLoading = true;
        try {
            const response = await api.listFiles(this.currentPath);
            this.files = response.files;
            this.renderFiles();
            this.updateBreadcrumb();
            this.updateSidebarInfo();
        } catch (error) {
            ui.showNotification('Erro ao carregar arquivos', 'error');
            console.error(error);
        } finally {
            this.isLoading = false;
        }
    }

    /**
     * Renderiza lista de arquivos
     */
    renderFiles() {
        const filesList = document.getElementById('files-list');
        
        if (this.files.length === 0) {
            filesList.innerHTML = '<div class="empty-state"><span>📭</span><p>Nenhum arquivo nesta pasta</p></div>';
            return;
        }

        filesList.innerHTML = this.files.map(file => this.createFileElement(file)).join('');

        // Adicionar event listeners
        document.querySelectorAll('.file-item').forEach(item => {
            const filePath = item.getAttribute('data-path');
            const fileType = item.getAttribute('data-type');

            // Download/Abrir pasta
            item.addEventListener('dblclick', () => {
                if (fileType === 'dir') {
                    this.currentPath = filePath;
                    this.loadFiles();
                } else {
                    this.handleDownload(filePath);
                }
            });

            // Menu de ações
            const deleteBtn = item.querySelector('.delete-btn');
            const shareBtn = item.querySelector('.share-btn');

            if (deleteBtn) {
                deleteBtn.addEventListener('click', () => {
                    this.handleDelete(filePath, fileType);
                });
            }

            if (shareBtn) {
                shareBtn.addEventListener('click', () => {
                    this.handleShare(filePath);
                });
            }
        });
    }

    /**
     * Cria elemento de arquivo
     */
    createFileElement(file) {
        const isDir = file.type === 'dir';
        const icon = isDir ? '📁' : this.getFileIcon(file.name);
        const size = isDir ? '' : `<div class="file-size">${this.formatFileSize(file.size)}</div>`;

        return `
            <div class="file-item" data-path="${file.path}" data-type="${file.type}">
                <div class="file-icon">${icon}</div>
                <div class="file-name" title="${file.name}">${file.name}</div>
                ${size}
                <div class="file-actions">
                    ${!isDir ? `<button class="file-action-btn share-btn" title="Compartilhar">🔗</button>` : ''}
                    <button class="file-action-btn delete-btn" title="Deletar">🗑️</button>
                </div>
            </div>
        `;
    }

    /**
     * Obtém ícone do arquivo baseado na extensão
     */
    getFileIcon(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        const icons = {
            'pdf': '📄',
            'doc': '📝', 'docx': '📝',
            'xls': '📊', 'xlsx': '📊',
            'ppt': '🎯', 'pptx': '🎯',
            'zip': '📦', 'rar': '📦', '7z': '📦',
            'jpg': '🖼️', 'jpeg': '🖼️', 'png': '🖼️', 'gif': '🖼️',
            'mp3': '🎵', 'mp4': '🎬', 'avi': '🎬',
            'txt': '📄', 'md': '📝',
            'exe': '⚙️', 'msi': '⚙️',
            'html': '🌐', 'css': '🎨', 'js': '⚡',
        };
        return icons[ext] || '📄';
    }

    /**
     * Trata seleção de arquivos
     */
    async handleFileSelect(files) {
        if (files.length === 0) return;

        for (let file of files) {
            await this.uploadFile(file);
        }
    }

    /**
     * Faz upload de arquivo
     */
    async uploadFile(file) {
        // Validações
        if (file.size > 100 * 1024 * 1024) {
            ui.showNotification(`Arquivo ${file.name} é muito grande (máx 100MB)`, 'error');
            return;
        }

        // Mostrar progresso
        const progressContainer = document.getElementById('upload-progress-container');
        progressContainer.style.display = 'block';
        document.getElementById('upload-filename').textContent = file.name;
        document.getElementById('progress-percent').textContent = '0%';
        document.getElementById('progress-speed').textContent = '0 KB/s';

        this.uploadStartTime = Date.now();
        let lastTime = this.uploadStartTime;
        let lastLoaded = 0;

        try {
            await api.uploadFile(
                file,
                this.currentPath,
                (event) => {
                    if (event.lengthComputable) {
                        const percent = Math.round((event.loaded / event.total) * 100);
                        const fill = document.getElementById('progress-fill');
                        fill.style.width = percent + '%';
                        document.getElementById('progress-percent').textContent = percent + '%';

                        // Calcular velocidade
                        const now = Date.now();
                        const timeDiff = (now - lastTime) / 1000;
                        if (timeDiff > 0.5) {
                            const loadedDiff = event.loaded - lastLoaded;
                            const speed = (loadedDiff / timeDiff / 1024).toFixed(2);
                            document.getElementById('progress-speed').textContent = speed + ' KB/s';
                            lastTime = now;
                            lastLoaded = event.loaded;
                        }

                        // Tempo estimado
                        const elapsedTime = (now - this.uploadStartTime) / 1000;
                        const totalTime = elapsedTime / (event.loaded / event.total);
                        const remainingTime = totalTime - elapsedTime;
                        const minutes = Math.floor(remainingTime / 60);
                        const seconds = Math.floor(remainingTime % 60);
                        document.getElementById('progress-time').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                    }
                }
            );

            ui.showNotification(`Arquivo ${file.name} enviado com sucesso!`, 'success');
            this.loadFiles();
        } catch (error) {
            ui.showNotification(`Erro ao enviar ${file.name}`, 'error');
            console.error(error);
        }

        // Esconder progresso após 2 segundos
        setTimeout(() => {
            progressContainer.style.display = 'none';
        }, 2000);
    }

    /**
     * Trata download de arquivo
     */
    async handleDownload(filePath) {
        try {
            ui.showNotification('Iniciando download...', 'info');
            await api.downloadFile(filePath);
        } catch (error) {
            ui.showNotification('Erro ao fazer download', 'error');
            console.error(error);
        }
    }

    /**
     * Trata deleção de arquivo
     */
    async handleDelete(filePath, fileType) {
        const itemType = fileType === 'dir' ? 'pasta' : 'arquivo';
        if (!confirm(`Tem certeza que deseja deletar esta ${itemType}?`)) {
            return;
        }

        try {
            await api.deleteFile(filePath);
            ui.showNotification(`${itemType.charAt(0).toUpperCase() + itemType.slice(1)} deletado com sucesso!`, 'success');
            this.loadFiles();
        } catch (error) {
            ui.showNotification(`Erro ao deletar ${itemType}`, 'error');
            console.error(error);
        }
    }

    /**
     * Trata criação de pasta
     */
    async handleCreateFolder() {
        const folderName = document.getElementById('folder-name').value.trim();

        if (!folderName) {
            ui.showNotification('Digite o nome da pasta', 'error');
            return;
        }

        try {
            await api.createFolder(folderName, this.currentPath);
            ui.showNotification('Pasta criada com sucesso!', 'success');
            document.getElementById('folder-form').reset();
            ui.closeModal('folder-modal');
            this.loadFiles();
        } catch (error) {
            ui.showNotification('Erro ao criar pasta', 'error');
            console.error(error);
        }
    }

    /**
     * Trata compartilhamento de arquivo
     */
    handleShare(filePath) {
        document.getElementById('share-form').dataset.filePath = filePath;
        document.getElementById('share-result').style.display = 'none';
        document.getElementById('generate-share-btn').style.display = 'block';
        ui.openModal('share-modal');
    }

    /**
     * Cria link de compartilhamento
     */
    async handleCreateShareLink() {
        const filePath = document.getElementById('share-form').dataset.filePath;
        const expirationHours = parseInt(document.getElementById('share-expiration').value);
        const viewLimit = document.getElementById('share-view-limit').value ? parseInt(document.getElementById('share-view-limit').value) : null;
        const password = document.getElementById('share-password').value || null;

        try {
            const response = await api.createShareLink(filePath, expirationHours, password, viewLimit);
            
            // Mostrar resultado
            document.getElementById('share-result').style.display = 'block';
            document.getElementById('generate-share-btn').style.display = 'none';
            
            const fullUrl = window.location.origin + response.share_link;
            document.getElementById('share-link-input').value = fullUrl;
            
            ui.showNotification('Link de compartilhamento criado!', 'success');
        } catch (error) {
            ui.showNotification('Erro ao criar link de compartilhamento', 'error');
            console.error(error);
        }
    }

    /**
     * Trata busca de arquivos
     */
    handleSearch(query) {
        const fileItems = document.querySelectorAll('.file-item');
        const lowerQuery = query.toLowerCase();

        fileItems.forEach(item => {
            const name = item.querySelector('.file-name').textContent.toLowerCase();
            item.style.display = name.includes(lowerQuery) ? '' : 'none';
        });
    }

    /**
     * Atualiza breadcrumb
     */
    updateBreadcrumb() {
        const breadcrumbPath = document.getElementById('breadcrumb-path');
        
        if (!this.currentPath) {
            breadcrumbPath.innerHTML = '';
            return;
        }

        const parts = this.currentPath.split('/').filter(p => p);
        let path = '';
        
        breadcrumbPath.innerHTML = parts.map((part, index) => {
            path += part + '/';
            return `<a href="#" class="breadcrumb-item" data-path="${path.slice(0, -1)}">${part}</a>`;
        }).join('');
    }

    /**
     * Atualiza informações da sidebar
     */
    updateSidebarInfo() {
        const totalSize = this.files.reduce((sum, file) => sum + (file.size || 0), 0);
        const fileCount = this.files.filter(f => f.type === 'file').length;

        document.getElementById('total-size').textContent = this.formatFileSize(totalSize);
        document.getElementById('file-count').textContent = fileCount;
    }

    /**
     * Formata tamanho de arquivo
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
    }
}

// Inicializar aplicação
const app = new CloudApp();
