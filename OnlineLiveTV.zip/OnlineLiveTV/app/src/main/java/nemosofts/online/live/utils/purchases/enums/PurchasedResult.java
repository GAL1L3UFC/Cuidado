package nemosofts.online.live.utils.purchases.enums;

public enum PurchasedResult {
    CLIENT_NOT_READY,
    PURCHASED_PRODUCTS_NOT_FETCHED_YET,
    YES,
    NO
}