package nemosofts.online.live.interfaces;

public interface InterAdListener {
    void onClick(int position, String type);
}